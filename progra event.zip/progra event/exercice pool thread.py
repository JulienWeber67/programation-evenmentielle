import time
import concurrent.futures
import requests
import threading
import sys

def main():
    def task(i):
        print(f"Task {i} starts for {i} second(s)")
        time.sleep(1)
        print(f"Task {i} ends")

    start = time.perf_counter()

    t1 = threading.Thread(target=task, args=[1])
    t1.start()
    t2 = threading.Thread(target=task, args=[2])
    t2.start()
    t3 = threading.Thread(target=task, args=[3])
    t3.start()
    t1.join()
    t2.join()
    t3.join()

img_urls = [
  'https://cdn.pixabay.com/photo/2022/10/31/18/44/spider-web-7560535_960_720.jpg'
]

def download_image(img_url):
    img_bytes = requests.get(img_url).content
    img_name = img_url.split('/')[4]
    with open(img_name, 'wb') as img_file:
        img_file.write(img_bytes)
        print(f"{img_name} was downloaded")

start = time.perf_counter()


with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(download_image, img_urls)


end = time.perf_counter()
print(f"Tasks ended in {round(end - start, 2)} second(s)")

if __name__==main():
        sys.exit()